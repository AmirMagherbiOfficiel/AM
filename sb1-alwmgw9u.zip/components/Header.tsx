import { StyleSheet, View, Text, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';

export function Header() {
  const insets = useSafeAreaInsets();
  
  return (
    <LinearGradient
      colors={['#2E3192', '#1B1464']}
      style={[
        styles.header,
        { paddingTop: Platform.OS === 'web' ? 16 : insets.top }
      ]}>
      <View style={styles.logoContainer}>
        <Text style={styles.logoText}>AM</Text>
        <Text style={styles.logoSubtext}>Downloader</Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  header: {
    height: 80,
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  logoContainer: {
    alignItems: 'center',
  },
  logoText: {
    fontFamily: 'Roboto-Bold',
    fontSize: 32,
    color: '#FFFFFF',
    letterSpacing: 2,
  },
  logoSubtext: {
    fontFamily: 'Roboto-Regular',
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
    letterSpacing: 1,
    marginTop: -2,
  },
});