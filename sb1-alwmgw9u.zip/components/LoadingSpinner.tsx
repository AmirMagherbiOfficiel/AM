import { StyleSheet, View, ActivityIndicator, Text } from 'react-native';

type LoadingSpinnerProps = {
  message?: string;
};

export function LoadingSpinner({ message }: LoadingSpinnerProps) {
  return (
    <View style={styles.container}>
      <ActivityIndicator size="large" color="#007AFF" />
      {message && <Text style={styles.text}>{message}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    alignItems: 'center',
    gap: 12,
  },
  text: {
    color: '#666',
    fontSize: 14,
    textAlign: 'center',
  },
});