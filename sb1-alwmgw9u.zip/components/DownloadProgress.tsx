import { StyleSheet, View, Text, TouchableOpacity, Platform } from 'react-native';
import { X } from 'lucide-react-native';
import Animated, { 
  useAnimatedStyle,
  withTiming,
  Easing
} from 'react-native-reanimated';

type DownloadProgressProps = {
  progress: number;
  timeRemaining: string;
  onCancel: () => void;
};

export function DownloadProgress({ 
  progress, 
  timeRemaining,
  onCancel 
}: DownloadProgressProps) {
  const progressStyle = useAnimatedStyle(() => ({
    width: withTiming(`${progress}%`, {
      duration: 300,
      easing: Easing.bezier(0.4, 0, 0.2, 1),
    }),
  }));

  return (
    <View style={styles.container}>
      <View style={styles.progressContainer}>
        <Animated.View style={[styles.progressBar, progressStyle]} />
        <View style={styles.progressInfo}>
          <Text style={styles.progressText}>{progress}%</Text>
          <Text style={styles.timeText}>{timeRemaining}</Text>
        </View>
      </View>
      <TouchableOpacity
        style={styles.cancelButton}
        onPress={onCancel}
        accessibilityLabel="Cancel download"
      >
        <X size={20} color="#FF5733" />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    ...Platform.select({
      web: {
        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
      },
      default: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
        elevation: 3,
      },
    }),
  },
  progressContainer: {
    flex: 1,
    marginRight: 16,
  },
  progressBar: {
    height: 4,
    backgroundColor: '#2E3192',
    borderRadius: 2,
  },
  progressInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  progressText: {
    fontFamily: 'Roboto-Medium',
    fontSize: 14,
    color: '#2E3192',
  },
  timeText: {
    fontFamily: 'Roboto-Regular',
    fontSize: 14,
    color: '#666',
  },
  cancelButton: {
    padding: 8,
  },
});