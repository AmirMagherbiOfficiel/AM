export function isValidVideoUrl(url: string): boolean {
  try {
    const urlObj = new URL(url);
    const validDomains = [
      'youtube.com',
      'youtu.be',
      'vimeo.com',
      'dailymotion.com',
      'facebook.com',
      'fb.watch'
    ];
    
    return validDomains.some(domain => urlObj.hostname.includes(domain));
  } catch {
    return false;
  }
}