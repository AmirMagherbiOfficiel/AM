import { useState } from 'react';
import { StyleSheet, View, TextInput, TouchableOpacity, Text, Platform } from 'react-native';
import { Link, Download } from 'lucide-react-native';
import { Header } from '@/components/Header';
import { ErrorMessage } from '@/components/ErrorMessage';
import { DownloadProgress } from '@/components/DownloadProgress';
import { isValidVideoUrl } from '@/utils/validation';
import { LinearGradient } from 'expo-linear-gradient';

export default function DownloadScreen() {
  const [url, setUrl] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleDownload = async () => {
    setError(null);
    
    if (!url.trim()) {
      setError('Please enter a video URL');
      return;
    }

    if (!isValidVideoUrl(url)) {
      setError('Please enter a valid video URL');
      return;
    }

    setIsDownloading(true);
    setProgress(0);

    try {
      // Simulate download progress
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setIsDownloading(false);
            return 100;
          }
          return prev + 10;
        });
      }, 1000);

      if (Platform.OS === 'web') {
        window.open(url, '_blank');
      }
    } catch (err) {
      setError('An error occurred during download. Please try again.');
      setIsDownloading(false);
    }
  };

  const handleCancel = () => {
    setIsDownloading(false);
    setProgress(0);
  };

  return (
    <View style={styles.container}>
      <Header />
      
      <LinearGradient
        colors={['rgba(46, 49, 146, 0.05)', 'rgba(46, 49, 146, 0)']}
        style={styles.content}>
        <View style={styles.card}>
          <Text style={styles.title}>Download Videos</Text>
          <Text style={styles.subtitle}>Enter a video URL to start downloading</Text>

          {error && (
            <ErrorMessage 
              message={error}
              onRetry={handleDownload}
            />
          )}
          
          <View style={styles.inputContainer}>
            <Link size={20} color="#666" style={styles.inputIcon} />
            <TextInput
              style={styles.input}
              placeholder="Enter video URL..."
              value={url}
              onChangeText={(text) => {
                setUrl(text);
                setError(null);
              }}
              placeholderTextColor="#666"
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="url"
            />
          </View>

          {isDownloading ? (
            <DownloadProgress
              progress={progress}
              timeRemaining="About 2 minutes remaining"
              onCancel={handleCancel}
            />
          ) : (
            <TouchableOpacity
              style={[styles.button, !url && styles.buttonDisabled]}
              onPress={handleDownload}
              disabled={!url}>
              <Download size={24} color="white" />
              <Text style={styles.buttonText}>Download Now</Text>
            </TouchableOpacity>
          )}
        </View>

        <View style={styles.supportedSites}>
          <Text style={styles.supportedTitle}>Supported Platforms</Text>
          <View style={styles.sitesList}>
            {['YouTube', 'Vimeo', 'Facebook', 'DailyMotion'].map((site) => (
              <View key={site} style={styles.siteTag}>
                <Text style={styles.siteTagText}>{site}</Text>
              </View>
            ))}
          </View>
        </View>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontFamily: 'Roboto-Bold',
    fontSize: 28,
    color: '#1B1464',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontFamily: 'Roboto-Regular',
    fontSize: 16,
    color: '#666',
    marginBottom: 24,
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    ...Platform.select({
      web: {
        boxShadow: '0 8px 24px rgba(0, 0, 0, 0.08)',
      },
      default: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.08,
        shadowRadius: 24,
        elevation: 8,
      },
    }),
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F7FA',
    borderRadius: 12,
    paddingHorizontal: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  inputIcon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    height: 56,
    fontFamily: 'Roboto-Regular',
    fontSize: 16,
    color: '#333',
  },
  button: {
    backgroundColor: '#2E3192',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    height: 56,
  },
  buttonDisabled: {
    backgroundColor: '#C5C6D0',
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontFamily: 'Roboto-Medium',
    marginLeft: 12,
  },
  supportedSites: {
    marginTop: 32,
  },
  supportedTitle: {
    fontSize: 20,
    fontFamily: 'Roboto-Medium',
    color: '#1B1464',
    marginBottom: 16,
    textAlign: 'center',
  },
  sitesList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 12,
  },
  siteTag: {
    backgroundColor: 'rgba(46, 49, 146, 0.1)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  siteTagText: {
    color: '#2E3192',
    fontSize: 14,
    fontFamily: 'Roboto-Medium',
  },
});