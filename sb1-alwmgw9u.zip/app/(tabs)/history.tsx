import { StyleSheet, View, Text, ScrollView } from 'react-native';
import { Clock } from 'lucide-react-native';

export default function HistoryScreen() {
  // في التطبيق الحقيقي، سنقوم بجلب هذه البيانات من التخزين المحلي
  const downloads = [
    {
      id: '1',
      title: 'كيفية تعلم البرمجة',
      url: 'https://youtube.com/watch?v=123',
      date: '2024-01-20',
      status: 'completed',
    },
    {
      id: '2',
      title: 'شرح React Native',
      url: 'https://youtube.com/watch?v=456',
      date: '2024-01-19',
      status: 'completed',
    },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>سجل التنزيلات</Text>
      </View>

      <ScrollView style={styles.content}>
        {downloads.map((download) => (
          <View key={download.id} style={styles.downloadItem}>
            <View style={styles.downloadInfo}>
              <Text style={styles.downloadTitle}>{download.title}</Text>
              <Text style={styles.downloadUrl}>{download.url}</Text>
              <View style={styles.downloadMeta}>
                <Clock size={14} color="#666" />
                <Text style={styles.downloadDate}>{download.date}</Text>
              </View>
            </View>
            <View style={[
              styles.statusBadge,
              download.status === 'completed' && styles.statusCompleted
            ]}>
              <Text style={styles.statusText}>
                {download.status === 'completed' ? 'مكتمل' : 'جارٍ'}
              </Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    padding: 20,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  downloadItem: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  downloadInfo: {
    flex: 1,
  },
  downloadTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  downloadUrl: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  downloadMeta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  downloadDate: {
    fontSize: 12,
    color: '#666',
    marginLeft: 4,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 15,
    backgroundColor: '#E8F0FE',
  },
  statusCompleted: {
    backgroundColor: '#E6F4EA',
  },
  statusText: {
    fontSize: 12,
    color: '#1A73E8',
    fontWeight: '500',
  },
});